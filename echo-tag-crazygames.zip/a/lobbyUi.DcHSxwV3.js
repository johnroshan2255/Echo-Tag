import{B as e,D as t,R as n,S as r}from"./src.DXsRTiq_.js";import{t as i}from"./index.BDFdd2sK.js";import{o as a}from"./game.CAsimVQh.js";var o=e=>`#${e.toString(16).padStart(6,`0`)}`,s=e=>e.replace(/[&<>"']/g,e=>`&#${e.charCodeAt(0)};`),c=e=>e?`<span class="lobby-name">${s(e)}</span>`:``,l=(l,u,d,f,p)=>{let m=document.createElement(`div`);m.id=`lobby`,m.innerHTML=`
    <div id="lobby-shadow"><div id="lobby-card" class="px crt">
      <h2 id="lobby-title">${a.finding}</h2>
      <p id="lobby-code" hidden>${a.roomCode} <b></b><span>${a.shareIt}</span></p>
      <button id="lobby-invite" type="button" class="px-s bv" hidden>${a.copyLink}</button>
      <p id="lobby-count"></p>
      <div id="lobby-roster"></div>
      <div id="lobby-bots" class="px-s" hidden>
        <button id="bots-minus" type="button" aria-label="fewer bots">&#8211;</button>
        <span id="bots-label"></span>
        <button id="bots-plus" type="button" aria-label="more bots">+</button>
      </div>
      <div id="lobby-mins" class="px-s" hidden>
        <button id="mins-minus" type="button" aria-label="shorter round">&#8211;</button>
        <span id="mins-label"></span>
        <button id="mins-plus" type="button" aria-label="longer round">+</button>
      </div>
      <div id="lobby-map" class="px-s" hidden>
        <button id="map-minus" type="button" aria-label="previous map">&#9664;</button>
        <div id="map-preview">
          <canvas id="map-canvas"></canvas>
          <div id="map-foot">
            <span id="map-label"></span>
            <span id="map-pips"></span>
          </div>
        </div>
        <button id="map-plus" type="button" aria-label="next map">&#9654;</button>
      </div>
      <button id="lobby-start" type="button" class="px-s bv-a" hidden>${a.start}</button>
      <p id="lobby-hint"></p>
    </div></div>`;let h=document.createElement(`style`);h.textContent=`
    /* grid + margin:auto (not place-content) so a card taller than a landscape phone
       scrolls instead of clipping its top and bottom off-screen. */
    #lobby { position: fixed; inset: 0; z-index: 3; display: grid; overflow-y: auto;
      background: rgba(13, 10, 22, .72); font-family: system-ui, sans-serif; }
    /* Shadow on the wrapper: a same-element clip-path would clip the shadow away. */
    #lobby-shadow { margin: auto; filter: drop-shadow(8px 8px 0 rgba(0,0,0,.35)); }
    #lobby-card { background: #1d1830; border: 4px solid #3a3150; padding: 26px 34px;
      min-width: 300px; text-align: center; }
    #lobby-title { color: #f6f1ff; font: 400 13px/1.5 var(--pf); letter-spacing: .05em; margin: 0 0 14px; }
    #lobby-code { color: #b3a8c9; font-size: 12px; letter-spacing: .1em; margin: 0 0 14px; }
    #lobby-code b { display: block; color: #ffc07a; font: 400 24px/1.3 var(--pf);
      letter-spacing: .14em; margin: 8px 0 4px; }
    #lobby-code span { display: block; font-size: 11px; opacity: .8; }
    /* The invite button: the acquisition loop — one tap turns a room into a shareable
       link. Styled like the +/- chips, sized for thumbs. */
    #lobby-invite { pointer-events: auto; cursor: pointer; margin: 0 0 14px; min-height: 40px;
      padding: 10px 18px; border: 3px solid #3a3150; background: #262048; color: #e9ddff;
      font: 400 9px/1.4 var(--pf); letter-spacing: .04em; }
    #lobby-invite:active { background: #3a3150; }
    #lobby-invite.copied { border-color: #7ccb66; color: #a4dd85; }
    #lobby-roster { display: flex; flex-wrap: wrap; gap: 8px; justify-content: center;
      margin: 0 0 16px; max-width: 320px; }
    .lobby-dot { width: 22px; height: 22px; border: 3px solid rgba(0,0,0,.4); }
    .lobby-dot.bot { opacity: .38; }
    /* Square + (portal username): friends find each other by name, everyone else by colour. */
    .lobby-who { display: inline-flex; align-items: center; gap: 6px; }
    .lobby-name { font: 400 9px/1 var(--pf); color: #e9ddff; letter-spacing: .04em;
      max-width: 110px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    #lobby-start { pointer-events: auto; cursor: pointer; border: 0; padding: 14px 30px;
      font: 400 12px/1.4 var(--pf); letter-spacing: .04em; color: #241505;
      background: #ffc07a; }
    #lobby-start:active { transform: translate(2px, 2px); }
    #lobby-start:disabled { background: #574a3a; color: #2e2517; cursor: default;
      transform: none; }
    #lobby-count { color: #f6f1ff; font-size: 13px; letter-spacing: .12em; margin: 0 0 10px; }
    #lobby-bots, #lobby-mins, #lobby-map { pointer-events: auto; display: flex; gap: 0; justify-content: center;
      align-items: stretch; margin: 0 0 12px; }
    #lobby-bots[hidden], #lobby-mins[hidden], #lobby-map[hidden] { display: none; }
    #lobby-bots button, #lobby-mins button, #lobby-map button { cursor: pointer; width: 44px; min-height: 44px;
      border: 3px solid #3a3150; background: #262048; color: #e9ddff;
      font: 400 13px/1 var(--pf); }
    #lobby-bots button:active, #lobby-mins button:active, #lobby-map button:active { background: #3a3150; }
    #bots-label, #mins-label, #map-preview { display: flex; align-items: center; justify-content: center;
      min-width: 96px; padding: 10px 16px; color: #ffc07a;
      border: 3px solid #3a3150; border-left: 0; border-right: 0; font: 400 9px/1.5 var(--pf);
      letter-spacing: .04em; }
    /* The map row grows into a proper preview: a true miniature of the whole arena
       (20:11), so it takes the width the card can give it, capped by height on
       landscape phones. Hard corners — same brick language as everything else. */
    #lobby-map { width: min(80vw, 400px); margin-left: auto; margin-right: auto; }
    #map-preview { flex: 1; min-width: 0; flex-direction: column; padding: 8px; background: #1d1830; }
    #map-canvas { display: block; width: min(100%, calc(28vh * 20 / 11)); aspect-ratio: 20/11;
      margin: 0 auto 6px; border: 2px solid #3a3150; background: #262038; }
    #map-foot { display: flex; align-items: center; justify-content: space-between; gap: 8px;
      width: 100%; }
    #map-label { line-height: 1; text-shadow: none; white-space: nowrap; overflow: hidden;
      text-overflow: ellipsis; }
    #map-pips { display: flex; gap: 5px; flex-shrink: 0; }
    #map-pips i { width: 8px; height: 8px; background: #3a3150; }
    #map-pips i.on { background: #ffc07a; }
    #lobby-hint { color: #b3a8c9; font-size: 12px; margin: 12px 0 0; }
    #lobby.results #lobby-roster { flex-direction: column; align-items: stretch; }
    .lobby-row { display: flex; align-items: center; gap: 10px; color: #f6f1ff;
      font-size: 14px; justify-content: space-between; }
    .lobby-row .who { display: flex; align-items: center; gap: 10px; }
    .lobby-tag { font: 400 8px/1.4 var(--pf); letter-spacing: .04em;
      padding: 3px 6px; border: 2px solid rgba(0,0,0,.4); }
    .lobby-tag.win { background: #ffc07a; color: #241505; }
    .lobby-tag.lose { background: #574a3a; color: #f6f1ff; }
    /* Landscape phones: the card must fit ~390px of height with both host rows showing. */
    @media (max-height: 520px) {
      #lobby-card { padding: 12px 22px; }
      #lobby-title { font-size: 11px; margin: 0 0 8px; }
      #lobby-code { margin: 0 0 8px; }
      #lobby-code b { font-size: 16px; margin: 2px 0 0; }
      #lobby-count { margin: 0 0 6px; }
      #lobby-roster { margin: 0 0 10px; }
      #lobby-bots, #lobby-mins, #lobby-map { margin: 0 0 8px; }
      #lobby-map { margin-left: auto; margin-right: auto;
        width: min(80vw, calc(22vh * 20 / 11 + 114px)); }
      #map-canvas { width: min(100%, calc(22vh * 20 / 11)); }
      #lobby-start { padding: 10px 34px; min-height: 44px; }
      #lobby-hint { margin: 8px 0 0; }
    }
  `,m.prepend(h),document.body.appendChild(m);let g=m.querySelector(`#lobby-title`),_=m.querySelector(`#lobby-code`),v=_.querySelector(`b`),y=m.querySelector(`#lobby-invite`),b;y.addEventListener(`click`,()=>{let e=v.textContent??``;if(e.length!==5)return;let t=p?.(e)??`${location.origin}${location.pathname}?room=${e}`,n=()=>{y.textContent=a.copied,y.classList.add(`copied`),clearTimeout(b),b=setTimeout(()=>{y.textContent=a.copyLink,y.classList.remove(`copied`)},1600)};try{navigator.clipboard.writeText(t).then(n,()=>prompt(a.copyLink,t))}catch{prompt(a.copyLink,t)}});let x=m.querySelector(`#lobby-count`),S=m.querySelector(`#lobby-roster`),C=m.querySelector(`#lobby-bots`),w=m.querySelector(`#bots-label`),T=m.querySelector(`#bots-minus`),E=m.querySelector(`#bots-plus`),D=m.querySelector(`#lobby-mins`),O=m.querySelector(`#mins-label`),k=m.querySelector(`#mins-minus`),A=m.querySelector(`#mins-plus`),j=m.querySelector(`#lobby-map`),M=m.querySelector(`#map-label`),N=m.querySelector(`#map-pips`);N.innerHTML=`<i class="px-xs"></i>`.repeat(4);let P=m.querySelector(`#map-minus`),F=m.querySelector(`#map-plus`),I=m.querySelector(`#map-canvas`),L=I.getContext(`2d`),R=m.querySelector(`#lobby-start`),z=m.querySelector(`#lobby-hint`);R.addEventListener(`click`,l);let B=null;T.addEventListener(`click`,()=>{B&&u?.(Math.max(0,B.bots-1))}),E.addEventListener(`click`,()=>{B&&u?.(Math.min(12-B.humans,B.bots+1))}),k.addEventListener(`click`,()=>{B&&d?.(Math.max(3,B.roundMins-1))}),A.addEventListener(`click`,()=>{B&&d?.(Math.min(12,B.roundMins+1))}),P.addEventListener(`click`,()=>{B&&f?.((B.mapIndex-1+4)%4)}),F.addEventListener(`click`,()=>{B&&f?.((B.mapIndex+1)%4)});let V=e=>{let t=r[e];t&&(I.width=640,I.height=352,i(L,t,640,352),N.querySelectorAll(`i`).forEach((t,n)=>t.classList.toggle(`on`,n===e)))};return{update(i){B=i;let l=i.phase===t.Lobby,u=i.phase===t.Leaderboard;if(m.style.display=l||u?`grid`:`none`,m.classList.toggle(`results`,u),!(!l&&!u)){if(l){let t=Math.min(12,i.humans+(i.isPrivate?i.bots:0));g.textContent=i.isPrivate?a.yourRoom:a.finding,_.hidden=!i.isPrivate,y.hidden=!i.isPrivate,v.textContent=i.code,x.textContent=i.isPrivate?`${i.humans} / 12 ${a.players}`:`${i.humans} ${a.joined}`,C.hidden=!(i.isPrivate&&i.isHost),w.textContent=`${a.bots}: ${i.bots}`,D.hidden=!(i.isPrivate&&i.isHost),O.textContent=`${a.round}: ${i.roundMins} ${a.min}`,j.hidden=!1;let s=i.isPrivate&&i.isHost;P.style.visibility=s?`visible`:`hidden`,F.style.visibility=P.style.visibility,M.textContent=`${r[i.mapIndex]?.name?.toUpperCase()??`UNKNOWN`} · ${n[i.mapIndex]??``}`,V(i.mapIndex);let l=i.humans+i.bots>=2;R.hidden=!(i.isPrivate&&i.isHost),R.disabled=!l,z.textContent=i.isPrivate?i.isHost?l?a.hintCanStart(t,i.roundMins,i.humans):a.hintNeedOne:a.hintWaitHost(i.roundMins):a.hintPublic(i.humans),S.innerHTML=i.scores.map(t=>`<span class="lobby-who"><span class="lobby-dot px-xs${t.isBot?` bot`:``}" style="background:${o(e[t.colorSlot%e.length])}"></span>${c(t.name)}</span>`).join(``)}else{g.textContent=a.roundOver,_.hidden=!0,y.hidden=!0,R.hidden=!0,C.hidden=!0,D.hidden=!0,j.hidden=!0,z.textContent=a.hintResults;let t=i.scores[i.scores.length-1],n=i.scores[i.scores.length-2];S.innerHTML=i.scores.map((r,c)=>{let l=c===0&&i.scores.length>1?`<span class="lobby-tag px-xs win">${a.winner}</span>`:c===i.scores.length-1&&n&&t.itTimeMs>n.itTimeMs?`<span class="lobby-tag px-xs lose">${a.lost}</span>`:``;return`<div class="lobby-row"><span class="who"><span class="lobby-dot${r.isBot?` bot`:``}" style="background:${o(e[r.colorSlot%e.length])}"></span>#${c+1}${r.name?` · ${s(r.name)}`:``}${r.isBot?` · ${a.bot}`:``}</span><span>${l} ${r.caught>0?`<span style="opacity:.6">${a.caught} ${r.caught}x · </span>`:``}${(r.itTimeMs/1e3).toFixed(1)}s</span></div>`}).join(``)}}},destroy(){m.remove()}}};export{l as createLobbyUi};