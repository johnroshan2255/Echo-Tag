import{y as e}from"./index.B-8zmBUG.js";import{u as t}from"./game.BSgH-Zuq.js";var n=e=>`#${e.toString(16).padStart(6,`0`)}`,r=r=>{let i=document.createElement(`div`);i.id=`lobby`,i.innerHTML=`
    <div id="lobby-card">
      <h2 id="lobby-title">WAITING FOR PLAYERS</h2>
      <p id="lobby-code" hidden>ROOM CODE <b></b><span>share it with your friends</span></p>
      <div id="lobby-roster"></div>
      <button id="lobby-start" type="button" hidden>START ROUND</button>
      <p id="lobby-hint"></p>
    </div>`;let a=document.createElement(`style`);a.textContent=`
    #lobby { position: fixed; inset: 0; z-index: 3; display: grid; place-content: center;
      background: rgba(13, 10, 22, .72); font-family: system-ui, sans-serif; }
    #lobby-card { background: #1d1830; border: 4px solid #3a3150; padding: 26px 34px;
      min-width: 300px; text-align: center; box-shadow: 8px 8px 0 rgba(0,0,0,.35); }
    #lobby-title { color: #f6f1ff; font-size: 18px; letter-spacing: .14em; margin: 0 0 14px; }
    #lobby-code { color: #b3a8c9; font-size: 12px; letter-spacing: .1em; margin: 0 0 14px; }
    #lobby-code b { display: block; color: #ffc07a; font-size: 34px; letter-spacing: .3em;
      margin: 6px 0 2px; }
    #lobby-code span { display: block; font-size: 11px; opacity: .8; }
    #lobby-roster { display: flex; flex-wrap: wrap; gap: 8px; justify-content: center;
      margin: 0 0 16px; max-width: 320px; }
    .lobby-dot { width: 22px; height: 22px; border: 3px solid rgba(0,0,0,.4); }
    .lobby-dot.bot { opacity: .38; }
    #lobby-start { pointer-events: auto; cursor: pointer; border: 0; padding: 14px 34px;
      font: 800 16px/1 system-ui, sans-serif; letter-spacing: .12em; color: #241505;
      background: #ffc07a; box-shadow: 4px 4px 0 rgba(0,0,0,.4); }
    #lobby-start:active { transform: translate(2px, 2px); box-shadow: 2px 2px 0 rgba(0,0,0,.4); }
    #lobby-hint { color: #b3a8c9; font-size: 12px; margin: 12px 0 0; }
    #lobby.results #lobby-roster { flex-direction: column; align-items: stretch; }
    .lobby-row { display: flex; align-items: center; gap: 10px; color: #f6f1ff;
      font-size: 14px; justify-content: space-between; }
    .lobby-row .who { display: flex; align-items: center; gap: 10px; }
  `,i.prepend(a),document.body.appendChild(i);let o=i.querySelector(`#lobby-title`),s=i.querySelector(`#lobby-code`),c=s.querySelector(`b`),l=i.querySelector(`#lobby-roster`),u=i.querySelector(`#lobby-start`),d=i.querySelector(`#lobby-hint`);return u.addEventListener(`click`,r),{update(r){let a=r.phase===t.Lobby,f=r.phase===t.Leaderboard;i.style.display=a||f?`grid`:`none`,i.classList.toggle(`results`,f),!(!a&&!f)&&(a?(o.textContent=r.isPrivate?`YOUR ROOM`:`FINDING PLAYERS`,s.hidden=!r.isPrivate,c.textContent=r.code,u.hidden=!(r.isPrivate&&r.isHost),d.textContent=r.isPrivate?r.isHost?`${r.humans} here — empty seats become bots`:`waiting for the host to start`:`${r.humans} joined — starting shortly, bots fill the rest`,l.innerHTML=r.scores.map(t=>`<div class="lobby-dot${t.isBot?` bot`:``}" style="background:${n(e[t.colorSlot%e.length])}"></div>`).join(``)):(o.textContent=`ROUND OVER`,s.hidden=!0,u.hidden=!0,d.textContent=`least time as It wins — next round starting`,l.innerHTML=r.scores.map((t,r)=>`<div class="lobby-row"><span class="who"><span class="lobby-dot${t.isBot?` bot`:``}" style="background:${n(e[t.colorSlot%e.length])}"></span>#${r+1}${t.isBot?` · bot`:``}</span><span>${(t.itTimeMs/1e3).toFixed(1)}s</span></div>`).join(``)))},destroy(){i.remove()}}};export{r as createLobbyUi};