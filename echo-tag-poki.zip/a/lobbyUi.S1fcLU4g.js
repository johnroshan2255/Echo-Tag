import{P as e,w as t,y as n}from"./src.Db33IPOI.js";import{t as r}from"./index.CRzWCM5o.js";var i=e=>`#${e.toString(16).padStart(6,`0`)}`,a=(a,o,s,c)=>{let l=document.createElement(`div`);l.id=`lobby`,l.innerHTML=`
    <div id="lobby-card">
      <h2 id="lobby-title">WAITING FOR PLAYERS</h2>
      <p id="lobby-code" hidden>ROOM CODE <b></b><span>share it with your friends</span></p>
      <p id="lobby-count"></p>
      <div id="lobby-roster"></div>
      <div id="lobby-bots" hidden>
        <button id="bots-minus" type="button" aria-label="fewer bots">&#8211;</button>
        <span id="bots-label"></span>
        <button id="bots-plus" type="button" aria-label="more bots">+</button>
      </div>
      <div id="lobby-mins" hidden>
        <button id="mins-minus" type="button" aria-label="shorter round">&#8211;</button>
        <span id="mins-label"></span>
        <button id="mins-plus" type="button" aria-label="longer round">+</button>
      </div>
      <div id="lobby-map" hidden>
        <button id="map-minus" type="button" aria-label="previous map">&#9664;</button>
        <div id="map-preview">
          <canvas id="map-canvas"></canvas>
          <div id="map-foot">
            <span id="map-label"></span>
            <span id="map-pips"></span>
          </div>
        </div>
        <button id="map-plus" type="button" aria-label="next map">&#9654;</button>
      </div>
      <button id="lobby-start" type="button" hidden>START ROUND</button>
      <p id="lobby-hint"></p>
    </div>`;let u=document.createElement(`style`);u.textContent=`
    /* grid + margin:auto (not place-content) so a card taller than a landscape phone
       scrolls instead of clipping its top and bottom off-screen. */
    #lobby { position: fixed; inset: 0; z-index: 3; display: grid; overflow-y: auto;
      background: rgba(13, 10, 22, .72); font-family: system-ui, sans-serif; }
    #lobby-card { background: #1d1830; border: 4px solid #3a3150; padding: 26px 34px;
      min-width: 300px; text-align: center; box-shadow: 8px 8px 0 rgba(0,0,0,.35);
      margin: auto; }
    #lobby-title { color: #f6f1ff; font-size: 18px; letter-spacing: .14em; margin: 0 0 14px; }
    #lobby-code { color: #b3a8c9; font-size: 12px; letter-spacing: .1em; margin: 0 0 14px; }
    #lobby-code b { display: block; color: #ffc07a; font-size: 34px; letter-spacing: .3em;
      margin: 6px 0 2px; }
    #lobby-code span { display: block; font-size: 11px; opacity: .8; }
    #lobby-roster { display: flex; flex-wrap: wrap; gap: 8px; justify-content: center;
      margin: 0 0 16px; max-width: 320px; }
    .lobby-dot { width: 22px; height: 22px; border: 3px solid rgba(0,0,0,.4); }
    .lobby-dot.bot { opacity: .38; }
    #lobby-start { pointer-events: auto; cursor: pointer; border: 0; padding: 14px 34px;
      font: 800 16px/1 system-ui, sans-serif; letter-spacing: .12em; color: #241505;
      background: #ffc07a; box-shadow: 4px 4px 0 rgba(0,0,0,.4); }
    #lobby-start:active { transform: translate(2px, 2px); box-shadow: 2px 2px 0 rgba(0,0,0,.4); }
    #lobby-start:disabled { background: #574a3a; color: #2e2517; cursor: default;
      transform: none; box-shadow: 4px 4px 0 rgba(0,0,0,.4); }
    #lobby-count { color: #f6f1ff; font-size: 13px; letter-spacing: .12em; margin: 0 0 10px; }
    #lobby-bots, #lobby-mins, #lobby-map { pointer-events: auto; display: flex; gap: 0; justify-content: center;
      align-items: stretch; margin: 0 0 12px; }
    #lobby-bots[hidden], #lobby-mins[hidden], #lobby-map[hidden] { display: none; }
    #lobby-bots button, #lobby-mins button, #lobby-map button { cursor: pointer; width: 44px; min-height: 44px;
      border: 3px solid #3a3150; background: #262048; color: #e9ddff;
      font: 800 18px/1 ui-monospace, monospace; }
    #lobby-bots button:active, #lobby-mins button:active, #lobby-map button:active { background: #3a3150; }
    #bots-label, #mins-label, #map-preview { display: flex; align-items: center; justify-content: center;
      min-width: 96px; padding: 10px 16px; color: #ffc07a;
      border: 3px solid #3a3150; border-left: 0; border-right: 0; font: 800 13px/1 ui-monospace, monospace;
      letter-spacing: .12em; }
    /* The map row grows into a proper preview: a true miniature of the whole arena
       (20:11), so it takes the width the card can give it, capped by height on
       landscape phones. Hard corners — same brick language as everything else. */
    #lobby-map { width: min(80vw, 400px); margin-left: auto; margin-right: auto; }
    #map-preview { flex: 1; min-width: 0; flex-direction: column; padding: 8px; background: #1d1830; }
    #map-canvas { display: block; width: min(100%, calc(28vh * 20 / 11)); aspect-ratio: 20/11;
      margin: 0 auto 6px; border: 2px solid #3a3150; background: #262038; }
    #map-foot { display: flex; align-items: center; justify-content: space-between; gap: 8px;
      width: 100%; }
    #map-label { line-height: 1; text-shadow: none; white-space: nowrap; overflow: hidden;
      text-overflow: ellipsis; }
    #map-pips { display: flex; gap: 5px; flex-shrink: 0; }
    #map-pips i { width: 8px; height: 8px; background: #3a3150; }
    #map-pips i.on { background: #ffc07a; }
    #lobby-hint { color: #b3a8c9; font-size: 12px; margin: 12px 0 0; }
    #lobby.results #lobby-roster { flex-direction: column; align-items: stretch; }
    .lobby-row { display: flex; align-items: center; gap: 10px; color: #f6f1ff;
      font-size: 14px; justify-content: space-between; }
    .lobby-row .who { display: flex; align-items: center; gap: 10px; }
    .lobby-tag { font: 800 10px/1 ui-monospace, monospace; letter-spacing: .12em;
      padding: 3px 6px; border: 2px solid rgba(0,0,0,.4); }
    .lobby-tag.win { background: #ffc07a; color: #241505; }
    .lobby-tag.lose { background: #574a3a; color: #f6f1ff; }
    /* Landscape phones: the card must fit ~390px of height with both host rows showing. */
    @media (max-height: 520px) {
      #lobby-card { padding: 12px 22px; }
      #lobby-title { font-size: 15px; margin: 0 0 8px; }
      #lobby-code { margin: 0 0 8px; }
      #lobby-code b { font-size: 22px; margin: 2px 0 0; }
      #lobby-count { margin: 0 0 6px; }
      #lobby-roster { margin: 0 0 10px; }
      #lobby-bots, #lobby-mins, #lobby-map { margin: 0 0 8px; }
      #lobby-map { margin-left: auto; margin-right: auto;
        width: min(80vw, calc(22vh * 20 / 11 + 114px)); }
      #map-canvas { width: min(100%, calc(22vh * 20 / 11)); }
      #lobby-start { padding: 10px 34px; min-height: 44px; }
      #lobby-hint { margin: 8px 0 0; }
    }
  `,l.prepend(u),document.body.appendChild(l);let d=l.querySelector(`#lobby-title`),f=l.querySelector(`#lobby-code`),p=f.querySelector(`b`),m=l.querySelector(`#lobby-count`),h=l.querySelector(`#lobby-roster`),g=l.querySelector(`#lobby-bots`),_=l.querySelector(`#bots-label`),v=l.querySelector(`#bots-minus`),y=l.querySelector(`#bots-plus`),b=l.querySelector(`#lobby-mins`),x=l.querySelector(`#mins-label`),S=l.querySelector(`#mins-minus`),C=l.querySelector(`#mins-plus`),w=l.querySelector(`#lobby-map`),T=l.querySelector(`#map-label`),E=l.querySelector(`#map-pips`);E.innerHTML=`<i></i>`.repeat(4);let D=l.querySelector(`#map-minus`),O=l.querySelector(`#map-plus`),k=l.querySelector(`#map-canvas`),A=k.getContext(`2d`),j=l.querySelector(`#lobby-start`),M=l.querySelector(`#lobby-hint`);j.addEventListener(`click`,a);let N=null;v.addEventListener(`click`,()=>{N&&o?.(Math.max(0,N.bots-1))}),y.addEventListener(`click`,()=>{N&&o?.(Math.min(12-N.humans,N.bots+1))}),S.addEventListener(`click`,()=>{N&&s?.(Math.max(3,N.roundMins-1))}),C.addEventListener(`click`,()=>{N&&s?.(Math.min(12,N.roundMins+1))}),D.addEventListener(`click`,()=>{N&&c?.((N.mapIndex-1+4)%4)}),O.addEventListener(`click`,()=>{N&&c?.((N.mapIndex+1)%4)});let P=e=>{let t=n[e];t&&(k.width=640,k.height=352,r(A,t,640,352),E.querySelectorAll(`i`).forEach((t,n)=>t.classList.toggle(`on`,n===e)))};return{update(r){N=r;let a=r.phase===t.Lobby,o=r.phase===t.Leaderboard;if(l.style.display=a||o?`grid`:`none`,l.classList.toggle(`results`,o),!(!a&&!o)){if(a){let t=Math.min(12,r.humans+(r.isPrivate?r.bots:0));d.textContent=r.isPrivate?`YOUR ROOM`:`FINDING PLAYERS`,f.hidden=!r.isPrivate,p.textContent=r.code,m.textContent=r.isPrivate?`${r.humans} / 12 PLAYERS`:`${r.humans} JOINED`,g.hidden=!(r.isPrivate&&r.isHost),_.textContent=`BOTS: ${r.bots}`,b.hidden=!(r.isPrivate&&r.isHost),x.textContent=`ROUND: ${r.roundMins} MIN`,w.hidden=!1;let a=r.isPrivate&&r.isHost;D.style.visibility=a?`visible`:`hidden`,O.style.visibility=D.style.visibility,T.textContent=n[r.mapIndex]?.name?.toUpperCase()??`UNKNOWN`,P(r.mapIndex);let o=r.humans+r.bots>=2;j.hidden=!(r.isPrivate&&r.isHost),j.disabled=!o,M.textContent=r.isPrivate?r.isHost?o?`${t} will play, ${r.roundMins} min — add bots or start with just your ${r.humans}`:`you need one more player — add a bot or share the code`:`waiting for the host to start — ${r.roundMins} min round`:`${r.humans} joined — starting shortly, bots fill the rest`,h.innerHTML=r.scores.map(t=>`<div class="lobby-dot${t.isBot?` bot`:``}" style="background:${i(e[t.colorSlot%e.length])}"></div>`).join(``)}else{d.textContent=`ROUND OVER`,f.hidden=!0,j.hidden=!0,g.hidden=!0,b.hidden=!0,w.hidden=!0,M.textContent=`least time as the ghost wins — next round starting`;let t=r.scores[r.scores.length-1],n=r.scores[r.scores.length-2];h.innerHTML=r.scores.map((a,o)=>{let s=o===0&&r.scores.length>1?`<span class="lobby-tag win">WINNER</span>`:o===r.scores.length-1&&n&&t.itTimeMs>n.itTimeMs?`<span class="lobby-tag lose">LOST</span>`:``;return`<div class="lobby-row"><span class="who"><span class="lobby-dot${a.isBot?` bot`:``}" style="background:${i(e[a.colorSlot%e.length])}"></span>#${o+1}${a.isBot?` · bot`:``}</span><span>${s} ${a.caught>0?`<span style="opacity:.6">caught ${a.caught}x · </span>`:``}${(a.itTimeMs/1e3).toFixed(1)}s</span></div>`}).join(``)}}},destroy(){l.remove()}}};export{a as createLobbyUi};