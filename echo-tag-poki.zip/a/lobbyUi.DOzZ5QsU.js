import{B as e,D as t,R as n,S as r}from"./src.C13PvtFB.js";import{t as i}from"./index.D-MGDZf4.js";var a=e=>`#${e.toString(16).padStart(6,`0`)}`,o=(o,s,c,l)=>{let u=document.createElement(`div`);u.id=`lobby`,u.innerHTML=`
    <div id="lobby-card">
      <h2 id="lobby-title">WAITING FOR PLAYERS</h2>
      <p id="lobby-code" hidden>ROOM CODE <b></b><span>share it with your friends</span></p>
      <p id="lobby-count"></p>
      <div id="lobby-roster"></div>
      <div id="lobby-bots" hidden>
        <button id="bots-minus" type="button" aria-label="fewer bots">&#8211;</button>
        <span id="bots-label"></span>
        <button id="bots-plus" type="button" aria-label="more bots">+</button>
      </div>
      <div id="lobby-mins" hidden>
        <button id="mins-minus" type="button" aria-label="shorter round">&#8211;</button>
        <span id="mins-label"></span>
        <button id="mins-plus" type="button" aria-label="longer round">+</button>
      </div>
      <div id="lobby-map" hidden>
        <button id="map-minus" type="button" aria-label="previous map">&#9664;</button>
        <div id="map-preview">
          <canvas id="map-canvas"></canvas>
          <div id="map-foot">
            <span id="map-label"></span>
            <span id="map-pips"></span>
          </div>
        </div>
        <button id="map-plus" type="button" aria-label="next map">&#9654;</button>
      </div>
      <button id="lobby-start" type="button" hidden>START ROUND</button>
      <p id="lobby-hint"></p>
    </div>`;let d=document.createElement(`style`);d.textContent=`
    /* grid + margin:auto (not place-content) so a card taller than a landscape phone
       scrolls instead of clipping its top and bottom off-screen. */
    #lobby { position: fixed; inset: 0; z-index: 3; display: grid; overflow-y: auto;
      background: rgba(13, 10, 22, .72); font-family: system-ui, sans-serif; }
    #lobby-card { background: #1d1830; border: 4px solid #3a3150; padding: 26px 34px;
      min-width: 300px; text-align: center; box-shadow: 8px 8px 0 rgba(0,0,0,.35);
      margin: auto; }
    #lobby-title { color: #f6f1ff; font-size: 18px; letter-spacing: .14em; margin: 0 0 14px; }
    #lobby-code { color: #b3a8c9; font-size: 12px; letter-spacing: .1em; margin: 0 0 14px; }
    #lobby-code b { display: block; color: #ffc07a; font-size: 34px; letter-spacing: .3em;
      margin: 6px 0 2px; }
    #lobby-code span { display: block; font-size: 11px; opacity: .8; }
    #lobby-roster { display: flex; flex-wrap: wrap; gap: 8px; justify-content: center;
      margin: 0 0 16px; max-width: 320px; }
    .lobby-dot { width: 22px; height: 22px; border: 3px solid rgba(0,0,0,.4); }
    .lobby-dot.bot { opacity: .38; }
    #lobby-start { pointer-events: auto; cursor: pointer; border: 0; padding: 14px 34px;
      font: 800 16px/1 system-ui, sans-serif; letter-spacing: .12em; color: #241505;
      background: #ffc07a; box-shadow: 4px 4px 0 rgba(0,0,0,.4); }
    #lobby-start:active { transform: translate(2px, 2px); box-shadow: 2px 2px 0 rgba(0,0,0,.4); }
    #lobby-start:disabled { background: #574a3a; color: #2e2517; cursor: default;
      transform: none; box-shadow: 4px 4px 0 rgba(0,0,0,.4); }
    #lobby-count { color: #f6f1ff; font-size: 13px; letter-spacing: .12em; margin: 0 0 10px; }
    #lobby-bots, #lobby-mins, #lobby-map { pointer-events: auto; display: flex; gap: 0; justify-content: center;
      align-items: stretch; margin: 0 0 12px; }
    #lobby-bots[hidden], #lobby-mins[hidden], #lobby-map[hidden] { display: none; }
    #lobby-bots button, #lobby-mins button, #lobby-map button { cursor: pointer; width: 44px; min-height: 44px;
      border: 3px solid #3a3150; background: #262048; color: #e9ddff;
      font: 800 18px/1 ui-monospace, monospace; }
    #lobby-bots button:active, #lobby-mins button:active, #lobby-map button:active { background: #3a3150; }
    #bots-label, #mins-label, #map-preview { display: flex; align-items: center; justify-content: center;
      min-width: 96px; padding: 10px 16px; color: #ffc07a;
      border: 3px solid #3a3150; border-left: 0; border-right: 0; font: 800 13px/1 ui-monospace, monospace;
      letter-spacing: .12em; }
    /* The map row grows into a proper preview: a true miniature of the whole arena
       (20:11), so it takes the width the card can give it, capped by height on
       landscape phones. Hard corners — same brick language as everything else. */
    #lobby-map { width: min(80vw, 400px); margin-left: auto; margin-right: auto; }
    #map-preview { flex: 1; min-width: 0; flex-direction: column; padding: 8px; background: #1d1830; }
    #map-canvas { display: block; width: min(100%, calc(28vh * 20 / 11)); aspect-ratio: 20/11;
      margin: 0 auto 6px; border: 2px solid #3a3150; background: #262038; }
    #map-foot { display: flex; align-items: center; justify-content: space-between; gap: 8px;
      width: 100%; }
    #map-label { line-height: 1; text-shadow: none; white-space: nowrap; overflow: hidden;
      text-overflow: ellipsis; }
    #map-pips { display: flex; gap: 5px; flex-shrink: 0; }
    #map-pips i { width: 8px; height: 8px; background: #3a3150; }
    #map-pips i.on { background: #ffc07a; }
    #lobby-hint { color: #b3a8c9; font-size: 12px; margin: 12px 0 0; }
    #lobby.results #lobby-roster { flex-direction: column; align-items: stretch; }
    .lobby-row { display: flex; align-items: center; gap: 10px; color: #f6f1ff;
      font-size: 14px; justify-content: space-between; }
    .lobby-row .who { display: flex; align-items: center; gap: 10px; }
    .lobby-tag { font: 800 10px/1 ui-monospace, monospace; letter-spacing: .12em;
      padding: 3px 6px; border: 2px solid rgba(0,0,0,.4); }
    .lobby-tag.win { background: #ffc07a; color: #241505; }
    .lobby-tag.lose { background: #574a3a; color: #f6f1ff; }
    /* Landscape phones: the card must fit ~390px of height with both host rows showing. */
    @media (max-height: 520px) {
      #lobby-card { padding: 12px 22px; }
      #lobby-title { font-size: 15px; margin: 0 0 8px; }
      #lobby-code { margin: 0 0 8px; }
      #lobby-code b { font-size: 22px; margin: 2px 0 0; }
      #lobby-count { margin: 0 0 6px; }
      #lobby-roster { margin: 0 0 10px; }
      #lobby-bots, #lobby-mins, #lobby-map { margin: 0 0 8px; }
      #lobby-map { margin-left: auto; margin-right: auto;
        width: min(80vw, calc(22vh * 20 / 11 + 114px)); }
      #map-canvas { width: min(100%, calc(22vh * 20 / 11)); }
      #lobby-start { padding: 10px 34px; min-height: 44px; }
      #lobby-hint { margin: 8px 0 0; }
    }
  `,u.prepend(d),document.body.appendChild(u);let f=u.querySelector(`#lobby-title`),p=u.querySelector(`#lobby-code`),m=p.querySelector(`b`),h=u.querySelector(`#lobby-count`),g=u.querySelector(`#lobby-roster`),_=u.querySelector(`#lobby-bots`),v=u.querySelector(`#bots-label`),y=u.querySelector(`#bots-minus`),b=u.querySelector(`#bots-plus`),x=u.querySelector(`#lobby-mins`),S=u.querySelector(`#mins-label`),C=u.querySelector(`#mins-minus`),w=u.querySelector(`#mins-plus`),T=u.querySelector(`#lobby-map`),E=u.querySelector(`#map-label`),D=u.querySelector(`#map-pips`);D.innerHTML=`<i></i>`.repeat(4);let O=u.querySelector(`#map-minus`),k=u.querySelector(`#map-plus`),A=u.querySelector(`#map-canvas`),j=A.getContext(`2d`),M=u.querySelector(`#lobby-start`),N=u.querySelector(`#lobby-hint`);M.addEventListener(`click`,o);let P=null;y.addEventListener(`click`,()=>{P&&s?.(Math.max(0,P.bots-1))}),b.addEventListener(`click`,()=>{P&&s?.(Math.min(12-P.humans,P.bots+1))}),C.addEventListener(`click`,()=>{P&&c?.(Math.max(3,P.roundMins-1))}),w.addEventListener(`click`,()=>{P&&c?.(Math.min(12,P.roundMins+1))}),O.addEventListener(`click`,()=>{P&&l?.((P.mapIndex-1+4)%4)}),k.addEventListener(`click`,()=>{P&&l?.((P.mapIndex+1)%4)});let F=e=>{let t=r[e];t&&(A.width=640,A.height=352,i(j,t,640,352),D.querySelectorAll(`i`).forEach((t,n)=>t.classList.toggle(`on`,n===e)))};return{update(i){P=i;let o=i.phase===t.Lobby,s=i.phase===t.Leaderboard;if(u.style.display=o||s?`grid`:`none`,u.classList.toggle(`results`,s),!(!o&&!s)){if(o){let t=Math.min(12,i.humans+(i.isPrivate?i.bots:0));f.textContent=i.isPrivate?`YOUR ROOM`:`FINDING PLAYERS`,p.hidden=!i.isPrivate,m.textContent=i.code,h.textContent=i.isPrivate?`${i.humans} / 12 PLAYERS`:`${i.humans} JOINED`,_.hidden=!(i.isPrivate&&i.isHost),v.textContent=`BOTS: ${i.bots}`,x.hidden=!(i.isPrivate&&i.isHost),S.textContent=`ROUND: ${i.roundMins} MIN`,T.hidden=!1;let o=i.isPrivate&&i.isHost;O.style.visibility=o?`visible`:`hidden`,k.style.visibility=O.style.visibility,E.textContent=`${r[i.mapIndex]?.name?.toUpperCase()??`UNKNOWN`} · ${n[i.mapIndex]??``}`,F(i.mapIndex);let s=i.humans+i.bots>=2;M.hidden=!(i.isPrivate&&i.isHost),M.disabled=!s,N.textContent=i.isPrivate?i.isHost?s?`${t} will play, ${i.roundMins} min — add bots or start with just your ${i.humans}`:`you need one more player — add a bot or share the code`:`waiting for the host to start — ${i.roundMins} min round`:`${i.humans} joined — starting shortly, bots fill the rest`,g.innerHTML=i.scores.map(t=>`<div class="lobby-dot${t.isBot?` bot`:``}" style="background:${a(e[t.colorSlot%e.length])}"></div>`).join(``)}else{f.textContent=`ROUND OVER`,p.hidden=!0,M.hidden=!0,_.hidden=!0,x.hidden=!0,T.hidden=!0,N.textContent=`least time as the monster wins — next round starting`;let t=i.scores[i.scores.length-1],n=i.scores[i.scores.length-2];g.innerHTML=i.scores.map((r,o)=>{let s=o===0&&i.scores.length>1?`<span class="lobby-tag win">WINNER</span>`:o===i.scores.length-1&&n&&t.itTimeMs>n.itTimeMs?`<span class="lobby-tag lose">LOST</span>`:``;return`<div class="lobby-row"><span class="who"><span class="lobby-dot${r.isBot?` bot`:``}" style="background:${a(e[r.colorSlot%e.length])}"></span>#${o+1}${r.isBot?` · bot`:``}</span><span>${s} ${r.caught>0?`<span style="opacity:.6">caught ${r.caught}x · </span>`:``}${(r.itTimeMs/1e3).toFixed(1)}s</span></div>`}).join(``)}}},destroy(){u.remove()}}};export{o as createLobbyUi};