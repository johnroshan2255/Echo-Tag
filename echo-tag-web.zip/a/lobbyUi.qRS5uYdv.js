import{B as e,D as t,R as n,S as r}from"./src.DXsRTiq_.js";import{t as i}from"./index.Be_sp3zt.js";import{o as a}from"./game.KlFBvz5k.js";var o=e=>`#${e.toString(16).padStart(6,`0`)}`,s=(s,c,l,u)=>{let d=document.createElement(`div`);d.id=`lobby`,d.innerHTML=`
    <div id="lobby-card">
      <h2 id="lobby-title">${a.finding}</h2>
      <p id="lobby-code" hidden>${a.roomCode} <b></b><span>${a.shareIt}</span></p>
      <button id="lobby-invite" type="button" hidden>${a.copyLink}</button>
      <p id="lobby-count"></p>
      <div id="lobby-roster"></div>
      <div id="lobby-bots" hidden>
        <button id="bots-minus" type="button" aria-label="fewer bots">&#8211;</button>
        <span id="bots-label"></span>
        <button id="bots-plus" type="button" aria-label="more bots">+</button>
      </div>
      <div id="lobby-mins" hidden>
        <button id="mins-minus" type="button" aria-label="shorter round">&#8211;</button>
        <span id="mins-label"></span>
        <button id="mins-plus" type="button" aria-label="longer round">+</button>
      </div>
      <div id="lobby-map" hidden>
        <button id="map-minus" type="button" aria-label="previous map">&#9664;</button>
        <div id="map-preview">
          <canvas id="map-canvas"></canvas>
          <div id="map-foot">
            <span id="map-label"></span>
            <span id="map-pips"></span>
          </div>
        </div>
        <button id="map-plus" type="button" aria-label="next map">&#9654;</button>
      </div>
      <button id="lobby-start" type="button" hidden>${a.start}</button>
      <p id="lobby-hint"></p>
    </div>`;let f=document.createElement(`style`);f.textContent=`
    /* grid + margin:auto (not place-content) so a card taller than a landscape phone
       scrolls instead of clipping its top and bottom off-screen. */
    #lobby { position: fixed; inset: 0; z-index: 3; display: grid; overflow-y: auto;
      background: rgba(13, 10, 22, .72); font-family: system-ui, sans-serif; }
    #lobby-card { background: #1d1830; border: 4px solid #3a3150; padding: 26px 34px;
      min-width: 300px; text-align: center; box-shadow: 8px 8px 0 rgba(0,0,0,.35);
      margin: auto; }
    #lobby-title { color: #f6f1ff; font-size: 18px; letter-spacing: .14em; margin: 0 0 14px; }
    #lobby-code { color: #b3a8c9; font-size: 12px; letter-spacing: .1em; margin: 0 0 14px; }
    #lobby-code b { display: block; color: #ffc07a; font-size: 34px; letter-spacing: .3em;
      margin: 6px 0 2px; }
    #lobby-code span { display: block; font-size: 11px; opacity: .8; }
    /* The invite button: the acquisition loop — one tap turns a room into a shareable
       link. Styled like the +/- chips, sized for thumbs. */
    #lobby-invite { pointer-events: auto; cursor: pointer; margin: 0 0 14px; min-height: 40px;
      padding: 10px 18px; border: 3px solid #3a3150; background: #262048; color: #e9ddff;
      font: 800 12px/1 ui-monospace, monospace; letter-spacing: .12em; }
    #lobby-invite:active { background: #3a3150; }
    #lobby-invite.copied { border-color: #7ccb66; color: #a4dd85; }
    #lobby-roster { display: flex; flex-wrap: wrap; gap: 8px; justify-content: center;
      margin: 0 0 16px; max-width: 320px; }
    .lobby-dot { width: 22px; height: 22px; border: 3px solid rgba(0,0,0,.4); }
    .lobby-dot.bot { opacity: .38; }
    #lobby-start { pointer-events: auto; cursor: pointer; border: 0; padding: 14px 34px;
      font: 800 16px/1 system-ui, sans-serif; letter-spacing: .12em; color: #241505;
      background: #ffc07a; box-shadow: 4px 4px 0 rgba(0,0,0,.4); }
    #lobby-start:active { transform: translate(2px, 2px); box-shadow: 2px 2px 0 rgba(0,0,0,.4); }
    #lobby-start:disabled { background: #574a3a; color: #2e2517; cursor: default;
      transform: none; box-shadow: 4px 4px 0 rgba(0,0,0,.4); }
    #lobby-count { color: #f6f1ff; font-size: 13px; letter-spacing: .12em; margin: 0 0 10px; }
    #lobby-bots, #lobby-mins, #lobby-map { pointer-events: auto; display: flex; gap: 0; justify-content: center;
      align-items: stretch; margin: 0 0 12px; }
    #lobby-bots[hidden], #lobby-mins[hidden], #lobby-map[hidden] { display: none; }
    #lobby-bots button, #lobby-mins button, #lobby-map button { cursor: pointer; width: 44px; min-height: 44px;
      border: 3px solid #3a3150; background: #262048; color: #e9ddff;
      font: 800 18px/1 ui-monospace, monospace; }
    #lobby-bots button:active, #lobby-mins button:active, #lobby-map button:active { background: #3a3150; }
    #bots-label, #mins-label, #map-preview { display: flex; align-items: center; justify-content: center;
      min-width: 96px; padding: 10px 16px; color: #ffc07a;
      border: 3px solid #3a3150; border-left: 0; border-right: 0; font: 800 13px/1 ui-monospace, monospace;
      letter-spacing: .12em; }
    /* The map row grows into a proper preview: a true miniature of the whole arena
       (20:11), so it takes the width the card can give it, capped by height on
       landscape phones. Hard corners — same brick language as everything else. */
    #lobby-map { width: min(80vw, 400px); margin-left: auto; margin-right: auto; }
    #map-preview { flex: 1; min-width: 0; flex-direction: column; padding: 8px; background: #1d1830; }
    #map-canvas { display: block; width: min(100%, calc(28vh * 20 / 11)); aspect-ratio: 20/11;
      margin: 0 auto 6px; border: 2px solid #3a3150; background: #262038; }
    #map-foot { display: flex; align-items: center; justify-content: space-between; gap: 8px;
      width: 100%; }
    #map-label { line-height: 1; text-shadow: none; white-space: nowrap; overflow: hidden;
      text-overflow: ellipsis; }
    #map-pips { display: flex; gap: 5px; flex-shrink: 0; }
    #map-pips i { width: 8px; height: 8px; background: #3a3150; }
    #map-pips i.on { background: #ffc07a; }
    #lobby-hint { color: #b3a8c9; font-size: 12px; margin: 12px 0 0; }
    #lobby.results #lobby-roster { flex-direction: column; align-items: stretch; }
    .lobby-row { display: flex; align-items: center; gap: 10px; color: #f6f1ff;
      font-size: 14px; justify-content: space-between; }
    .lobby-row .who { display: flex; align-items: center; gap: 10px; }
    .lobby-tag { font: 800 10px/1 ui-monospace, monospace; letter-spacing: .12em;
      padding: 3px 6px; border: 2px solid rgba(0,0,0,.4); }
    .lobby-tag.win { background: #ffc07a; color: #241505; }
    .lobby-tag.lose { background: #574a3a; color: #f6f1ff; }
    /* Landscape phones: the card must fit ~390px of height with both host rows showing. */
    @media (max-height: 520px) {
      #lobby-card { padding: 12px 22px; }
      #lobby-title { font-size: 15px; margin: 0 0 8px; }
      #lobby-code { margin: 0 0 8px; }
      #lobby-code b { font-size: 22px; margin: 2px 0 0; }
      #lobby-count { margin: 0 0 6px; }
      #lobby-roster { margin: 0 0 10px; }
      #lobby-bots, #lobby-mins, #lobby-map { margin: 0 0 8px; }
      #lobby-map { margin-left: auto; margin-right: auto;
        width: min(80vw, calc(22vh * 20 / 11 + 114px)); }
      #map-canvas { width: min(100%, calc(22vh * 20 / 11)); }
      #lobby-start { padding: 10px 34px; min-height: 44px; }
      #lobby-hint { margin: 8px 0 0; }
    }
  `,d.prepend(f),document.body.appendChild(d);let p=d.querySelector(`#lobby-title`),m=d.querySelector(`#lobby-code`),h=m.querySelector(`b`),g=d.querySelector(`#lobby-invite`),_;g.addEventListener(`click`,()=>{let e=h.textContent??``;if(e.length!==5)return;let t=`${location.origin}${location.pathname}?room=${e}`,n=()=>{g.textContent=a.copied,g.classList.add(`copied`),clearTimeout(_),_=setTimeout(()=>{g.textContent=a.copyLink,g.classList.remove(`copied`)},1600)};try{navigator.clipboard.writeText(t).then(n,()=>prompt(a.copyLink,t))}catch{prompt(a.copyLink,t)}});let v=d.querySelector(`#lobby-count`),y=d.querySelector(`#lobby-roster`),b=d.querySelector(`#lobby-bots`),x=d.querySelector(`#bots-label`),S=d.querySelector(`#bots-minus`),C=d.querySelector(`#bots-plus`),w=d.querySelector(`#lobby-mins`),T=d.querySelector(`#mins-label`),E=d.querySelector(`#mins-minus`),D=d.querySelector(`#mins-plus`),O=d.querySelector(`#lobby-map`),k=d.querySelector(`#map-label`),A=d.querySelector(`#map-pips`);A.innerHTML=`<i></i>`.repeat(4);let j=d.querySelector(`#map-minus`),M=d.querySelector(`#map-plus`),N=d.querySelector(`#map-canvas`),P=N.getContext(`2d`),F=d.querySelector(`#lobby-start`),I=d.querySelector(`#lobby-hint`);F.addEventListener(`click`,s);let L=null;S.addEventListener(`click`,()=>{L&&c?.(Math.max(0,L.bots-1))}),C.addEventListener(`click`,()=>{L&&c?.(Math.min(12-L.humans,L.bots+1))}),E.addEventListener(`click`,()=>{L&&l?.(Math.max(3,L.roundMins-1))}),D.addEventListener(`click`,()=>{L&&l?.(Math.min(12,L.roundMins+1))}),j.addEventListener(`click`,()=>{L&&u?.((L.mapIndex-1+4)%4)}),M.addEventListener(`click`,()=>{L&&u?.((L.mapIndex+1)%4)});let R=e=>{let t=r[e];t&&(N.width=640,N.height=352,i(P,t,640,352),A.querySelectorAll(`i`).forEach((t,n)=>t.classList.toggle(`on`,n===e)))};return{update(i){L=i;let s=i.phase===t.Lobby,c=i.phase===t.Leaderboard;if(d.style.display=s||c?`grid`:`none`,d.classList.toggle(`results`,c),!(!s&&!c)){if(s){let t=Math.min(12,i.humans+(i.isPrivate?i.bots:0));p.textContent=i.isPrivate?a.yourRoom:a.finding,m.hidden=!i.isPrivate,g.hidden=!i.isPrivate,h.textContent=i.code,v.textContent=i.isPrivate?`${i.humans} / 12 ${a.players}`:`${i.humans} ${a.joined}`,b.hidden=!(i.isPrivate&&i.isHost),x.textContent=`${a.bots}: ${i.bots}`,w.hidden=!(i.isPrivate&&i.isHost),T.textContent=`${a.round}: ${i.roundMins} ${a.min}`,O.hidden=!1;let s=i.isPrivate&&i.isHost;j.style.visibility=s?`visible`:`hidden`,M.style.visibility=j.style.visibility,k.textContent=`${r[i.mapIndex]?.name?.toUpperCase()??`UNKNOWN`} · ${n[i.mapIndex]??``}`,R(i.mapIndex);let c=i.humans+i.bots>=2;F.hidden=!(i.isPrivate&&i.isHost),F.disabled=!c,I.textContent=i.isPrivate?i.isHost?c?a.hintCanStart(t,i.roundMins,i.humans):a.hintNeedOne:a.hintWaitHost(i.roundMins):a.hintPublic(i.humans),y.innerHTML=i.scores.map(t=>`<div class="lobby-dot${t.isBot?` bot`:``}" style="background:${o(e[t.colorSlot%e.length])}"></div>`).join(``)}else{p.textContent=a.roundOver,m.hidden=!0,g.hidden=!0,F.hidden=!0,b.hidden=!0,w.hidden=!0,O.hidden=!0,I.textContent=a.hintResults;let t=i.scores[i.scores.length-1],n=i.scores[i.scores.length-2];y.innerHTML=i.scores.map((r,s)=>{let c=s===0&&i.scores.length>1?`<span class="lobby-tag win">${a.winner}</span>`:s===i.scores.length-1&&n&&t.itTimeMs>n.itTimeMs?`<span class="lobby-tag lose">${a.lost}</span>`:``;return`<div class="lobby-row"><span class="who"><span class="lobby-dot${r.isBot?` bot`:``}" style="background:${o(e[r.colorSlot%e.length])}"></span>#${s+1}${r.isBot?` · ${a.bot}`:``}</span><span>${c} ${r.caught>0?`<span style="opacity:.6">${a.caught} ${r.caught}x · </span>`:``}${(r.itTimeMs/1e3).toFixed(1)}s</span></div>`}).join(``)}}},destroy(){d.remove()}}};export{s as createLobbyUi};